import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Clase Vida.
 * Se encarga de representar el marco del tablero que representa las vidas actuales que tiene el jugador.
 * 
 * @author Pedro Aldo Villela Briones.
 * @author Elva Nayeli Bárcenas López.
 * 
 * @version 1.0
 */
public class Vida extends Actor
{
    private GreenfootImage vida;
    
    /**
     * Act - El act de la clase Vida se encarga de crear la imagen que representa al marco del tablero de vidas así como su escala.
     */
    public void act() 
    {
     vida = new GreenfootImage("vida.png");
     vida.scale(70, 50);
     setImage(vida);
    }    
}
