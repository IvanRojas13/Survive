import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Tablero
 * Clase creada para llevar el control de las vidas que va teniendo el jugador.
 * 
 * @author Pedro Aldo Villela Briones
 * @author Elva Nayeli Bárcenas López
 * @version 1.0
 */
public class Tablero extends Actor
{
    GreenfootImage imagen;
    int cont;
    String mensaje;
    
    /**
     * Constructor de la clase Tablero.
     * Se encarga de inicializar las variables locales, así como crear la imagen que 
     * fungirá como el tablero, además define el color y el tipo de fuente 
     * para el número que mostrará cuantas vidas se tienen.
     * 
     * @param c Es la vida que llega al  tablero como entero.
     * @param msj Es el mensaje que se mostrará a un lado del número de vidas.
     */
    public Tablero(int c,  String msj)
    {
        cont = c;
        mensaje = msj;
        imagen = new GreenfootImage(70, 50);
        imagen.setColor(new Color(255,255,0));
        imagen.setFont(new Font("Verdana", false, false, 24));
        dibuja();
    }
    
    /**
     * Método dibuja.
     * Este método se encarga de dibujar en el tablero el número de vidas que tiene 
     * el jugador. Cada vez que gane o pierda una vida se representará en el tablero.
     */
    public void dibuja()
    {
      imagen.clear();
      imagen.drawString(mensaje + cont, 30, 30);
      setImage(imagen);
    }

    
    /**
     * Método incrementar.
     * Este método se encarga de incrementar en una unidad al entero que representa 
     * las vidas del jugador en el tablero.
     */
    public void incrementar()
    {
      cont++;
      dibuja();
    } 
    
    /**
     * Método decrementar.
     * Este método se encarga de decrementar en una unidad al entero que representa
     * las vidas del jugador en el tablero.
     */
    public void decrementar()
    {
        cont--;
        dibuja();
    }
}