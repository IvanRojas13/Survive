import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Clase Enemigo.
 * Esta clase funge como SuperClase de los enemigos.
 * 
 * @author Pedro Aldo Villela Briones.
 * @author Elva Nayeli Bárcenas López.
 * 
 * @version 1.0
 */
public class Enemigo extends Actor
{
    /**
     * Act - El act de la Clase Enemigo se encarga de llamar al método movimiento
     */
    public void act() 
    {
        movimiento();
    }   
    
    /**
     * Este método se encarga de realizar el movimiento para los enemigos. Verifica 
     * si un enemigo se encuentra en el borde del escenario y logra la ilusión del rebote.
     */
    public void movimiento()
    {
        move(2);
        if(this.isAtEdge())
        {
             setLocation(this.getX() + 1800, this.getY());
             move(50);
             turn(Greenfoot.getRandomNumber(180));
        }
    }
    }
