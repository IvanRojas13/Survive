import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Clase Roca.
 * Esta clase representa al objeto Roca del grupo de obstáculos.
 * 
 * @author Pedro Aldo Villela Briones.
 * @author Elva Nayeli Bárcenas López.
 * 
 * @version 1.0
 */
public class Roca extends Obstaculo
{
    private GreenfootImage roca;
    
    /**
     * Act - El act de la clase Roca se encarga de crear la imagen que representa a la roca así como su escala.
     */
    public void act() 
    {
        roca = new GreenfootImage("roca.png");
        roca.scale(70, 70);
        setImage(roca);
    }    
}
