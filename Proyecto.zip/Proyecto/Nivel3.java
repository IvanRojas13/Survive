import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Clase nivel 3.
 * Se encarga de pintar los objetos que se mostraran en el nivel puerta, jugador, 
 * vidas, bonus, vidas extras, llave, obstàculos(roca y muro), enemigos(serpiente, dmeonio,
 *  fuego, bomba, fantasma).
 * 
 * @author Pedro Aldo Villela Briones
 * @author Elva Nayeli Bárcenas López
 * @version (1.0)
 */
public class Nivel3 extends World
{
    private int vid;
    private int niv;
    private int bon;
    private int llaveubk;
    
    Counter count;
    SimpleTimer tim;
    Jugador jug;
    Tablero tablero;
    
    /**
     * Constructor de la clase Nivel3, es la encargada de pintar el nivel.
     * @param vida Recibe las vidas que tiene el jugador.
     * @param bonus Recibe los bonus que el jugador va reuniendo.
     * @param nivel Parámetro para dar paso al siguiente nivel.
     * @param llaveubik Recibe si el jugador ha tocado o no la llave.
     * 
     */
    public Nivel3(int vida, int bonus, int nivel, int llaveubik)
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 600, 1); 
        addObject(new Vida(), 150, 30);
        
        vid = vida;
        niv = nivel;
        bon = bonus;
        llaveubk = llaveubik;
        
        jug = new Jugador(vid, bon, niv, llaveubik);
        count = new Counter();
        tablero = new Tablero(vid, "");
         
        this.addObject(count, 50, 30);
        count.setValue(20);
        tim = new SimpleTimer();
        tim.mark();
        
        if(llaveubk == 0)
        {
        addObject(jug, 30, 510);
        
        addObject(tablero, 148, 34);
        
        addObject(new Demonio(), 30, 70);
         
        addObject(new Llave(), 450, 100);
        
        addObject(new Serpiente(), 790, 290);

        addObject(new Bomba(), 790, 270);
        
        addObject(new Fuego(), 790, 250);
        
        addObject(new Fantasma(), 790, 230);
        
        addObject(new Roca(), 40, 200);
        
        addObject(new Muro(), 400, 230);
       
      }
       else
          if(llaveubk == 1)
          {
       addObject(jug, 30, 510);
       
       addObject(tablero, 148, 34);
       
        addObject(new Puerta(), 780, 140);
        
        addObject(new Bonus(), 610, 100);
        addObject(new Bonus(), 650, 350);
         
        addObject(new Demonio(), 30, 70);
         
        addObject(new VidaExtra(), 400, 100);
        
        addObject(new Serpiente(), 790, 290);
        
        addObject(new Bomba(), 790, 270);
        
        addObject(new Fuego(), 790, 250);
        
        addObject(new Fantasma(), 790, 230);
        
        addObject(new Roca(), 200, 130);
        
        addObject(new Muro(), 400, 230);

       }
    }
    
    /**
     * Act que muestra en el juego el tiempo que le queda al jugador.
     */
    public void act()
    {
        if(tim.millisElapsed() > 1000)
        {
            tim.mark();
            count.setValue(count.getValue() - 1);
        }
    }
}
