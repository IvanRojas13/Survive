import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Clase Fantasma.
 * Esta clase representa al fantasma que forma parte del grupo de enemigos.
 * 
 * @author Pedro Aldo Villela Briones.
 * @author Elva Nayeli Bárcenas López.
 * 
 * @version 1.0
 */
public class Fantasma extends Enemigo
{
    private GreenfootImage fantasma;
    private GreenfootImage invisible;
    
    /**
     * Act - El act de la clase Fantasma se encarga de crear las imágenes que representarán al fantasma así como sus dimensiones.
     * Permite la ilusión de que el fantasma desaparece.
     * Hereda el movimiento de la ClaseMadre Enemigo.
     */ 
    public void act() 
    {
      fantasma = new GreenfootImage("fantasma.png");
      invisible = new GreenfootImage("invisible.png");
        
      fantasma.scale(80, 80);
      invisible.scale(80, 80);
      
      if(getX() >= 300 && getY() <= 450)
         setImage(fantasma);
          else
          setImage(invisible);
      
      super.movimiento();
    }   
}
