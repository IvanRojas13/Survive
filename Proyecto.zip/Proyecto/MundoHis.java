import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * MundoHis.
 * Mundo creado para poder redireccionar el rumbo del juego.
 * 
 *@author Pedro Aldo Villela Briones
 * @author Elva Nayeli Bárcenas López
 * 
 * @version (1.0)
 */
public class MundoHis extends World
{

    /**
     * Constructor de la clase MundoHis. Es la dimensión.
     * 
     */
    public MundoHis()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
    }
}
