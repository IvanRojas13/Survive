import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.io.IOException;
/**
 * Clase Jugador.
 * Esta clase describe al jugador, su movimiento.
 * 
 * @author Pedro Aldo Villela Briones
 * @author Elva Nayeli Bárcenas López
 * 
 * @version (1.0)
 */
public class Jugador extends Actor
{
    //Atras
    private GreenfootImage atras1;
    private GreenfootImage atras2;
     //Frente
    private GreenfootImage frente;
     //Derecha
    private GreenfootImage derecha1;
    private GreenfootImage derecha2;
    private GreenfootImage derecha3;
    private GreenfootImage derecha4;
    private GreenfootImage derecha5;
     //Izquierda
    private GreenfootImage izquierda1;
    private GreenfootImage izquierda2;
    private GreenfootImage izquierda3;
    private GreenfootImage izquierda4;
    private GreenfootImage frentei;
    
    private NombreNivel nn;

    private int vida;
    private int bonus;
    private int nivel;
    private int llaveubik;
    
    private SimpleTimer t = new SimpleTimer();
    /**
     * Constructor de la clase Jugador.
     * Se encarga de incialiar las imágenes del jugador, así como de inicializar 
     * las variables locales de vida, bonus, nivel y llaveubk.
     * 
     * @param vidas Representa las vidas del jugador.
     * @param bonus Representa a los bonus reunidos hasta el momento.
     * @param nivel Representa al nivel en el que nos encontramos.
     * @param llaveubik Representa una bandera para saber si se toco o no la llave.
     */
    public Jugador(int vidas, int bonus, int nivel, int llaveubik)
    {
        atras1 = new GreenfootImage("atras2.png");
        atras2 = new GreenfootImage("atras2.png");
        
        frente = new GreenfootImage("frente.png");
        
        derecha1 = new GreenfootImage("derecha1.png");
        derecha2 = new GreenfootImage("derecha2.png");
        derecha3 = new GreenfootImage("derecha3.png");
        derecha4 = new GreenfootImage("derecha4.png");
        derecha5 = new GreenfootImage("derecha5.png");
        
        izquierda1 = new GreenfootImage("izquierda1.png");
        izquierda2 = new GreenfootImage("izquierda2.png");
        izquierda3 = new GreenfootImage("izquierda3.png");
        izquierda4 = new GreenfootImage("izquierda4.png");
        frentei = new GreenfootImage("frentei.png");
        
        
        this.vida = vidas;
        this.bonus = bonus;
        this.nivel = nivel; 
        this.llaveubik = llaveubik;
        
        nn = new NombreNivel();
        bonus = 0;
        setImage(frente);
        t.mark();
    }

    /**
     * Act - El act de la clase Jugador se encarga de comparar en cual nivel nos encontramos,
     * cuándo estamos tocando la llave, el bonus, vida extra, la puerta, un obstáculo(Roca, Muro) 
     * o un enemigo(bomba, serpiente o el veneno de ésta, fuego, fantasma, demonio).
     * Llama al método movimiento.
     */
    public void act() 
    {
        if(vida == 0)
        {           
            Greenfoot.playSound("gameover.mp3");
            MundoHis mh = new MundoHis();
            NombreNivel nn = new NombreNivel();
            Greenfoot.setWorld(mh);
            mh.addObject(nn, 300, 200);
            Greenfoot.playSound("gameover.mp3");
            nn.escPerdio();
        }
           
        if(nivel == 1)
        {
            if(t.millisElapsed() >= 20000)
            {
                t.mark();
                quitarVida();
                llaveubik = 0;
                Nivel1 n1 = new Nivel1(vida, bonus, nivel, llaveubik);
                Greenfoot.setWorld(n1);
            }
        }
        
        if(nivel == 2)
        {
            if(t.millisElapsed() >= 20000)
            {
                t.mark();
                quitarVida();
                llaveubik = 0;
                Nivel2 n2 = new Nivel2(vida, bonus, nivel, llaveubik);
                Greenfoot.setWorld(n2);
            }
        }
        
        if(nivel == 3)
        {
            if(t.millisElapsed() >= 10000)
            {
                t.mark();
                quitarVida();
                llaveubik = 0;
                Nivel3 n3 = new Nivel3(vida, bonus, nivel, llaveubik);
                Greenfoot.setWorld(n3);
            }
        }
        
        if(isTouching(Bonus.class))
        {
            Greenfoot.playSound("bonus.mp3");
            bonus = bonus + 1;
            removeTouching(Bonus.class);
        }
        
        if(isTouching(Llave.class))
        {
            Greenfoot.playSound("llave.mp3");
            llaveubik = 1;    
            if(nivel == 1)
            {
             Nivel1 n1 = new Nivel1(vida, bonus, nivel, llaveubik);
             Greenfoot.setWorld(n1);
             }
             else
             if(nivel == 2)
                {
                 Nivel2 n2 = new Nivel2(vida, bonus, nivel, llaveubik);
                 Greenfoot.setWorld(n2);   
                }
                else
                   if(nivel == 3)
                     {
                         Nivel3 n3 = new Nivel3(vida, bonus, nivel, llaveubik);
                         Greenfoot.setWorld(n3);  
                        }
        }
        
        if(isTouching(VidaExtra.class))
        {
            removeTouching(VidaExtra.class);
            vida = vida + 1;
            Greenfoot.playSound("vidaextra.mp3");
            if(nivel == 1)
               {
                    Nivel1 n1 = new Nivel1(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n1);
                }
                else
                if(nivel == 2)
               {
                    Nivel2 n2 = new Nivel2(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n2);
                }
                else
                if(nivel == 3)
               {
                    Nivel3 n3= new Nivel3(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n3);
                }
        }       
        
        if(isTouching(Puerta.class))
        {
            if(nivel == 1)
            {
             MundoHis mh = new MundoHis();
            NombreNivel nn = new NombreNivel();
            Greenfoot.setWorld(mh);
            mh.addObject(nn, 300, 200);
            nn.escNivel2(bonus);
           }
           else
               if(nivel == 2)
               {
               MundoHis mh = new MundoHis();
               NombreNivel nn = new NombreNivel();
               Greenfoot.setWorld(mh);
               mh.addObject(nn, 300, 200);
               nn.escNivel3(bonus);
              }
              else
                  if(nivel == 3)
               {
               MundoHis mh = new MundoHis();
               NombreNivel nn = new NombreNivel();
               Greenfoot.setWorld(mh);
               mh.addObject(nn, 300, 200);
               nn.escFinal(bonus);
              }
       
        }
        movimiento();
        
        if(isTouching(Serpiente.class))
        {
            Greenfoot.playSound("enemigo.mp3");
            quitarVida();
            bonus = bonus;
            if(nivel == 1)
               {
                    Nivel1 n1 = new Nivel1(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n1);
                }
                else
                if(nivel == 2)
               {
                    Nivel2 n2 = new Nivel2(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n2);
                }
                else
                if(nivel == 3)
               {
                    Nivel3 n3= new Nivel3(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n3);
                }
        }
        
        if(isTouching(Veneno.class))
        {
            quitarVida();
            bonus = bonus;
            Greenfoot.playSound("ouch.mp3");
            if(nivel == 1)
               {
                    Nivel1 n1 = new Nivel1(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n1);
                }
                else
                if(nivel == 2)
               {
                    Nivel2 n2 = new Nivel2(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n2);
                }
                else
                if(nivel == 3)
               {
                    Nivel3 n3= new Nivel3(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n3);
                }
        }
        
        
         if(isTouching(Bomba.class))
        {
            Greenfoot.playSound("explosion.mp3");
            quitarVida();
            bonus = bonus;
        if(nivel == 1)
               {
                    Nivel1 n1 = new Nivel1(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n1);
                }
                else
                if(nivel == 2)
               {
                    Nivel2 n2 = new Nivel2(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n2);
                }
                else
                if(nivel == 3)
               {
                    Nivel3 n3= new Nivel3(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n3);
                }
        }

         if(isTouching(Fuego.class))
        {
            Greenfoot.playSound("enemigo.mp3");
            quitarVida();
            bonus = bonus;
           if(nivel == 1)
               {
                    Nivel1 n1 = new Nivel1(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n1);
                }
                else
                if(nivel == 2)
               {
                    Nivel2 n2 = new Nivel2(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n2);
                }
                else
                if(nivel == 3)
               {
                    Nivel3 n3= new Nivel3(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n3);
                }
        }
        
         if(isTouching(Fantasma.class))
        {
            Greenfoot.playSound("enemigo.mp3");
            quitarVida();
           if(nivel == 2)
               {
                    Nivel2 n2 = new Nivel2(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n2);
                }
                else
                if(nivel == 3)
               {
                    Nivel3 n3= new Nivel3(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n3);
                }
        }
        
         if(isTouching(Demonio.class))
        {
            Greenfoot.playSound("demonio.mp3");
            quitarVida();
            if(nivel == 2)
               {
                    Nivel2 n2 = new Nivel2(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n2);
                }
                else
                if(nivel == 3)
               {
                    Nivel3 n3= new Nivel3(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n3);
                }
        }
        
        if(isTouching(Roca.class) || isTouching(Muro.class))
        {
             setLocation(getX() - 2, getY() - 2);
             move(0);
        }
    }   
    
    
   /**
    * Este método permite al Jugador moverse en el escenario con ayuda de las teclas:
    * left, right, up o down(izquierda, derecha, arriba o abajo respectivamente).
    */
    public void movimiento()
    {
        if(Greenfoot.isKeyDown("right"))
         {
         setImage(frente);
         move(1);
         setImage(derecha1);
         setLocation(getX()+1, getY());
         setImage(derecha2);
         setLocation(getX()+1, getY());
         setImage(derecha3);
         setLocation(getX()+1, getY());
         setImage(derecha4);
         setLocation(getX()+1, getY());
         setImage(derecha5);
         setLocation(getX()+1, getY());
         }
       
        if(Greenfoot.isKeyDown("left"))
        {
         setImage(frentei);
         move(-1);
         setImage(izquierda1);
         setLocation(getX()-1, getY());
         setImage(izquierda2);
         setLocation(getX()-1, getY());
         setImage(izquierda3);
         setLocation(getX()-1, getY());
         setImage(izquierda4);
         setLocation(getX()-1, getY());
        }
        
        if(Greenfoot.isKeyDown("up"))
        {
         setImage(atras1);
         setLocation(getX(), getY()-3);
         setImage(atras2);
         setLocation(getX(), getY()-2);
        }
        
        if(Greenfoot.isKeyDown("down"))
        {
           setImage(frente);
           setLocation(getX(), getY() + 3);
        }
        
        if(isAtEdge())
          move(0);
    }
    
   /**
    * Este método decrementa la vida del Jugador en una unidad.
    */
    public void quitarVida()
    {
        vida = vida - 1;
    }
    
   /**
    * Este método permite avanzar de un nivel al otro.
    */
    public void siguienteNivel()
    {
        if(nivel == 1)
        {
           if(llaveubik == 0)
           {
               Nivel1 n1 = new Nivel1(vida, bonus, nivel, llaveubik);
               Greenfoot.setWorld(n1);
            }
            else
                nn.escNivel2(bonus);
         }
        else
          if(nivel == 2)
          {
             if(llaveubik == 0)
           {
               Nivel2 n2 = new Nivel2(vida, bonus, nivel, llaveubik);
               Greenfoot.setWorld(n2);
            }
            else
                nn.escNivel3(bonus);
          }
        else
          if(nivel == 3)
          {
             if(llaveubik == 0)
           {
               Nivel3 n3 = new Nivel3(vida, bonus, nivel, llaveubik);
               Greenfoot.setWorld(n3);
          }
        }
   }
}