import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Clase Serpiente.
 * Esta clase se encarga de representar a la serpiente que forma parte del grupo de enemigos.
 * 
 * @author Pedro Aldo Villela Briones.
 * @author Elva Nayeli Bárcenas López.
 * 
 * @version 1.0
 */
public class Serpiente extends Enemigo
{
    private GreenfootImage serpiente;
          
    /**
     * Act - El act de la clase Serpiente se encarga de crear la imagen que representa a la serpiente así como su escala.
     * Llama al método moviSer.
     */
    public void act() 
    {
      serpiente = new GreenfootImage("serpiente.png");
      serpiente.scale(70, 70);
      setImage(serpiente);
      movimSer();
    }  
    
    /**
     * Este método lleva a cabo el movimiento característico de las serpientes.
     */
    public void movimSer()
    {
        move(1);
        if(Greenfoot.getRandomNumber(100) > 10)
        {
           turn(Greenfoot.getRandomNumber(10) - 5);
           
        if(getX() <= 5 || getX() >= getWorld().getWidth() - 5)
        {
            turn(180);
        }
        
        if(getY() <= 5 || getY() >= getWorld().getHeight() - 5)
        {
            turn(180);
        }
        
        if(getX() == 100 || getX() == 200 || getX() == 300 || getX() == 400 || 
           getX() == 500 || getX() == 600 || getX() == 700 || getX() == 800)
          for(int i = 0; i < 1; i++ )
              disparar();
     }
    }
    
    /**
     * Este método se encarga de que la serpiente dispare.
     */
     public void disparar() 
     {
      getWorld().addObject(new Veneno(), getX(), getY());
    }
}
