import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * MyWorld
 * Este mundo es el que contiene los objetos botones y 
 * cada uno hace una accion diferente.
 * 
 * @author Pedro Aldo Villela Briones
 * @author Elva Nayeli Bàrcenas Lòpez
 * 
 * @version 1.0
 */
public class MyWorld extends World
{

    /**
     * Constructor de la clase MyWorld en el cual crea:
     * un objeto instrucciones 
     * un objeto salida
     * un objeto iniciar
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1280, 720, 1); 
        Greenfoot.playSound("menu.mp3");
        addObject(new Instrucciones(), 640, 300);
        addObject(new Iniciar(), 640, 450);
        addObject(new Salida(), 640, 600);
    }
}
