import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Clase VidaExtra.
 * Esta clase se encarga de representar al objeto vida extra en nuestro juego.
 * 
 * @author Pedro Aldo Villela Briones.
 * @author Elva Nayeli Bárcenas López.
 * 
 * @version 1.0
 */
public class VidaExtra extends Actor
{
    private GreenfootImage vidaExtra;
     
    /**
     * Act - El act de la clase VidaExtra se encarga de crear la imagen que representa a la vida extra así como su escala.
     */
    public void act() 
    {
      vidaExtra = new GreenfootImage("vidaExtra.png");
      vidaExtra.scale(25, 25);
      setImage(vidaExtra);
    }    
}
