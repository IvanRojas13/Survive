import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Clase Llave.
 * Esta clase representa al objeto llave.
 * 
 * @author Pedro Aldo Villela Briones.
 * @author Elva Nayeli Bárcenas López.
 * 
 * @version 1.0
 */
public class Llave extends Actor
{
    private GreenfootImage llave;
        
    /**
     * Act - El act de la clase Llave se encarga de crear la imagen que representa a la llave así como su escala.
     */
    public void act() 
    {
       llave = new GreenfootImage("llave.png");
        llave.scale(30, 30);
        setImage(llave);
    }    
}
