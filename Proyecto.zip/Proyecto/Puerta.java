import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Clase Puerta.
 * Esta clase representa al objeto Puerta.
 * 
 * @author Pedro Aldo Villela Briones.
 * @author Elva Nayeli Bárcenas López.
 * 
 * @version 1.0
 */
public class Puerta extends Actor
{
    private GreenfootImage puerta;
    
    /**
     * Act - El act de la clase Puerta se encraga de crear la imagen que representa a la puerta así como su escala.
     */
    public void act() 
    {
        puerta = new GreenfootImage("puerta.png");
        puerta.scale(90, 100);
        setImage(puerta);
    }    
}
