import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Clase Obtaculo.
 * Esta clase se encarga de representar a los obstáculos fijos que existen en el juego.
 * 
 * @author Pedro Aldo Villela Briones.
 * @version 1.0
 */
public abstract class Obstaculo extends Actor
{
    /**
     * Act  
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
