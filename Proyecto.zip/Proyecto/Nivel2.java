import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Clase nivel 2.
 * Se encarga de pintar los objetos que se mostraran en el nivel: puerta, jugador, 
 * vidas, bonus, vidas extras, llave, enemigos(demonio, bomba, fuego, fantasma, serpiente).
 * 
 * @author Pedro Aldo Villela Briones
 * @author Elva Nayeli Bárcenas López
 * @version (1.0)
 */
public class Nivel2 extends World
{
    private int vid;
    private int niv;
    private int bon;
    private int llaveubk;
    
    Counter count;
    SimpleTimer tim;
    Jugador jug;
    Tablero tablero;
    GreenfootImage go;

    /**
     * Constructor de la clase Nivel2, es la encargada de pintar el nivel.
     * @param vida Recibe las vidas que tiene el jugador.
     * @param bonus Recibe los bonus que el jugador va reuniendo.
     * @param nivel Parámetro para dar paso al siguiente nivel.
     * @param llaveubik Recibe si el jugador ha tocado o no la llave.
     * 
     */
    public Nivel2(int vida, int bonus, int nivel, int llaveubik)
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 600, 1); 
        addObject(new Vida(), 150, 30);
        
        vid = vida;
        niv = nivel;
        bon = bonus;
        llaveubk = llaveubik;

        jug = new Jugador(vid, bon, niv, llaveubik);        
        count = new Counter();
        tablero = new Tablero(vid, "");
        
        this.addObject(count, 50, 30);
        count.setValue(20);
        tim = new SimpleTimer();
        tim.mark();
        
        if(llaveubk == 0)
        {
        addObject( jug, 30, 510);
        
        addObject(tablero, 148, 34);
        
        addObject(new Llave(), 200, 100);

        addObject(new Demonio(), 30, 70);
        
        addObject(new Serpiente(), 790, 290);
        
        addObject(new Bomba(), 790, 270);
        addObject(new Bomba(), 790, 350);
        
        addObject(new Fuego(), 790, 250);
        addObject(new Fuego(), 790, 370);
        
        addObject(new Fantasma(), 790, 230);
        addObject(new Fantasma(), 790, 390);
        
    }
        else
           if(llaveubk == 1)
              {
        addObject( jug, 30, 510);
        
        addObject(tablero, 148, 34);
        
        addObject(new Puerta(), 780, 300);
        
        addObject(new Bonus(), 610, 100);
        
        addObject(new Demonio(), 30, 70);
        
        addObject(new VidaExtra(), 400, 100);
        
        addObject(new Serpiente(), 790, 290);
        
        addObject(new Bomba(), 790, 270);
        addObject(new Bomba(), 790, 350);
        
        addObject(new Fuego(), 790, 250);
        addObject(new Fuego(), 790, 370);
        
        addObject(new Fantasma(), 790, 230);
        addObject(new Fantasma(), 790, 390);
                }
    }
    
    /**
     * Act nos muestra en el juego el tiempo que le queda al jugador.
     */
    public void act()
    {
        if(tim.millisElapsed() > 1000)
        {
            tim.mark();
            count.setValue(count.getValue() - 1);
        }
    }
}
