import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Clase Veneno.
 * Esta clase representa al veneno que lanza la serpiente.
 * 
 * @author Pedro Aldo Villela Briones.
 * @author Elva Nayeli Bárcenas López.
 * 
 * @version 1.0
 */
public class Veneno extends Actor
{
    
    /**
     * Act - Llama al método desplaza.
     */
    public void act() 
    {
      desplaza();
    }   
    
     /**
     *Método para el desplazamiento del veneno.
     */
     public void desplaza() 
     {
         move(2);
       if(this.isAtEdge())
        {
             setLocation(this.getX() + 1800, this.getY());
             move(10);
             turn(Greenfoot.getRandomNumber(180));
        }
    }
}
