import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Classe Iniciar.
 * Esta clase se encarga de inicar el juego.
 * 
 * @author Pedro Aldo Villela Briones.
 * @author Elva Nayeli Bárcenas López.
 * 
 * @version (1.0)
 */
public class Iniciar extends Boton
{
    /**
     * Act - El act de la clase Iniciar se encarga de llamar al método tocar.
     */
    public void act() 
    {
        tocar();
    }    
    
    /**
     * Este método hace que el juego de inicio llamando al mundo historia y al objeto NombreNivel.
     */
    public void tocar()
    {
        if(Greenfoot.mouseClicked(this))
        {
            MundoHis his = new MundoHis();
            Greenfoot.setWorld(his);
            NombreNivel h = new NombreNivel();
            his.addObject(h, 300, 200);
             h.escInicio();
        }
    }
}
