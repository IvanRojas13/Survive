import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Clase Muro.
 * Esta clase se encarga de representar al muro del grupo de obstáculos.
 * 
 * @author Pedro Aldo Villela Briones.
 * @author Elva Nayeli Bárcenas López.
 * 
 * @version 1.0
 */
public class Muro extends Obstaculo
{
    private GreenfootImage muro;
        
    /**
     * Act - El act de la clase Muro se encarga de crear la imagen que representa al muro así como su escala.
     */
    public void act() 
    {
      muro = new GreenfootImage("muro.png");
      muro.scale(90, 90);
      setImage(muro);
    }      
}
