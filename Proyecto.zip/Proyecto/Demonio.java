import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Clase Demonio.
 * Esta clase representa al Demonio que forma parte del grupo de enemigos.
 * 
 * @author Pedro Aldo Villela Briones.
 * @author Elva Nayeli Bárcenas López.
 * 
 * @version 1.0
 */
public class Demonio extends Enemigo
{
    private GreenfootImage demonio;
    private GreenfootImage demonio2;
    private GreenfootImage demonio3;
    private GreenfootImage demonio4;
    private GreenfootImage demonio5;
    private GreenfootImage demonio6;
    private GreenfootImage demonio7;
    private int direccion = 1;
    private boolean cambia = false;
    private int velocidad = 4;
    
    /**
     * Act - El act de la clase Demonio se encarga de crear la imágen que representará al
     * demonio así como sus dimensiones. Llama al método moviDem.
     */
    public void act() 
    {   
        demonio = new GreenfootImage("demonio.png");
        demonio2 = new GreenfootImage("demonio2.png");
        demonio3 = new GreenfootImage("demonio3.png");
        demonio4 = new GreenfootImage("demonio4.png");
        demonio5 = new GreenfootImage("demonio5.png");
        demonio6 = new GreenfootImage("demonio6.png");
        demonio7 = new GreenfootImage("demonio7.png");
        demonio.scale(150, 150);
        demonio2.scale(150, 150);
        demonio3.scale(150, 150);
        demonio4.scale(150, 150);
        demonio5.scale(150, 150);
        demonio6.scale(150, 150);
        demonio7.scale(150, 150);
        setImage(demonio);
        moviDem();
    }    
    
    /**
     * Este método se encarga de llevar a cabo el movimiento del demonio.
     * Este método es especial, pues solo permite el demonio moverse de izquierda a derecha 
     * y viceversa.
     * 
     */
    public void moviDem()
    {
       if(getX() >= 30 && !cambia)
       {
          direccion = -1;
        }
       else{
          cambia = true;
        }
          
       if(getX() <= getWorld().getHeight() - 30 && cambia)
          direccion = 1;
       else
           cambia = false;
           
       setLocation(getX() + ( velocidad  * direccion), getY());
       
      if(getX() >= 100)
            setImage(demonio2);
      if(getX() >= 200)
            setImage(demonio3);
      if(getX() >= 300)
            setImage(demonio4);
      if(getX() >= 400)
            setImage(demonio5);
      if(getX() >= 500)
            setImage(demonio6);
    }
}
