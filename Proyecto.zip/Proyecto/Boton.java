import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Clase Boton.
 * Esta clase es abstracta, ya que solo se encarga de crear a los botones del menú.
 * 
 * @author Pedro Aldo Villela Briones.
 * @author Elva Nayeli Bárcenas López.
 * 
 * @version 1.0
 */
public abstract class Boton extends Actor
{
    /**
     * Act 
     */
    public void act() 
    {
        // Add your action code here.
    }    
    
    /**
     * Método abstracto.
     */
    public abstract void tocar();
}
