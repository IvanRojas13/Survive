import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Clase Bonus.
 * Esta clase representa al bonus del juego.
 * 
 * @author Pedro Aldo Villela Briones.
 * @author Elva Nayeli Bárcenas López.
 * 
 * @version 1.0
 */
public class Bonus extends Actor
{
    private GreenfootImage bonus;
    
    /**
     * Act - El act de la clase Bonus se encarga de crear la imagen que representa al bonus así como su escala.
     */
    public void act() 
    {
     bonus = new GreenfootImage("Moneda.png");
     bonus.scale(30, 30);
     setImage(bonus);
    }    
}
