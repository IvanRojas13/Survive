import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Clase Fuego.
 * Esta clase se encarga de representar al fuego que pertenece al grupo de enemigos.
 * 
 * @author Pedro Aldo Villela Briones.
 * @author Elva Nayeli Bárcenas López.
 * 
 * @version 1.0
 */
public class Fuego extends Enemigo
{
    private GreenfootImage fuego;
    /**
     * Act - El act de la Clase Fuego se encarga de crear la imagen que representa al fuego así como su escala.
     * Hereda el movimiento de la ClaseMadre Enemigo.
     */
    public void act() 
    {
        fuego = new GreenfootImage("fuego.png");
        fuego.scale(50, 50);
        setImage(fuego);
        super.movimiento();
    }    
}
