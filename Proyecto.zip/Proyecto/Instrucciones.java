import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Clase Instrucciones.
 * Esta clase llama al mundo instrucciones para que aparezca en la pantalla.
 * 
 * @author Pedro Aldo Villela Briones
 * @author Elva Nayeli Bárcenas López
 * 
 * @version (1.0)
 */
public class Instrucciones extends Boton
{
    /**
     * Act - El act de la clase Instrucciones se encarga de llamar al método tocar.
     */
    /**
     * Manda llamar a tocar
     */
    public void act() 
    {
        tocar();
    }    
    
    /**
     * Este método se encarga de detectar que se toca el botón y hace que cambie de mundo.
     */
    public void tocar()
    {
        if(Greenfoot.mouseClicked(this))
        {
            MundoInstr mu = new MundoInstr();
            Greenfoot.setWorld(mu);
        }
    }
}
