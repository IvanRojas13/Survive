import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Clase Bomba.
 * Esta clase representa a la bomba que forma parte del grupo de enemigos.
 * 
 * @author Pedro Aldo Villela Briones.
 * @author Elva Nayeli Bárcenas López.
 * 
 * @version 1.0
 */
public class Bomba extends Enemigo
{
    private GreenfootImage bomba;
    public GreenfootImage explosion;
     
    /**
     * Act - El act de la Clase Bomba se encarga de crear las imágenes que representarán a la bomba.
     * Define la escala de la bomba así como la ilusión de que la bomba explota.
     * Hereda el movimiento de la ClaseMadre Enemigo.
     */
    public void act() 
    {
        int i = 1;
        
       bomba = new GreenfootImage("bomba.png");
       explosion = new GreenfootImage("explosion.png");
       
       bomba.scale(50, 50);
       explosion.scale(50, 50);
       
       if(getX() >= 300 && getY() >= 100)
         setImage(bomba);
          else
          setImage(explosion);
                
       super.movimiento();
    }  
    }