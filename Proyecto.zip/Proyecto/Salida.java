import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Clase Salida.
 * Esta clase detiene la ejecucion del juego.
 * 
 * @author Pedro Aldo Villela Briones
 * @author Elva Nayeli Bárcenas López
 * 
 * @version (1.0)
 */
public class Salida extends Boton
{
    /**
     * Act - El act de la clase Salida se encarga de llamar al método tocar.
     */
    public void act() 
    {
        tocar();
    }    
    
    /**
     * Este método detecta si se tocó el botón de exit, e inmediatamente detiene el juego.
     */
    public void tocar()
    {
         if(Greenfoot.mouseClicked(this))
        {
            Greenfoot.stop();
        }
    }
}
