import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Class NombreNivel.
 * Hace que las imagenes de lo niveles se visualizen cuando deben entre la ejecucion del
 * juego.
 * 
 * @author Pedro Aldo Villela Briones
 * @author Elva Nayeli Bárcenas López
 * @version (1.0)
 */
public class NombreNivel extends Actor
{
     public NombreNivel()
    {
       
    }
       
    /**
     * Llamado a nivel 1
     */
    public void escInicio()
    { 
      int vidas = 3;
      int nivel = 1;
      int bonus = 0;
      int llaveubik = 0;
      
      Greenfoot.playSound("nivel.wav");
      setImage("niveluno.jpg");
      Greenfoot.delay(200); 
      Nivel1 n1 = new Nivel1(vidas, bonus, nivel, llaveubik);
      Greenfoot.setWorld(n1);
    }
    
    /**
     * Llamado a nivel 2
     */
    public void escNivel2(int bonus)
    { 
      int vida = 3;
      int nivel = 2;
      int llaveubik = 0;
      
      Greenfoot.playSound("nivel.wav");
      setImage("niveldos.jpg");
      Greenfoot.delay(200); 
      Nivel2 n2 = new Nivel2(vida, bonus, nivel, llaveubik);
      Greenfoot.setWorld(n2);
    }
    
     /**
     * Llamado a nivel 3
     */
    public void escNivel3(int bonus)
    { 
      int vida = 3;
      int nivel = 3;
      int llaveubik = 0;
      
      Greenfoot.playSound("nivel.wav");
      setImage("niveltres.jpg");
      Greenfoot.delay(200); 
      Nivel3 n3 = new Nivel3(vida, bonus, nivel, llaveubik);
      Greenfoot.setWorld(n3);
    }
    
    public void escPerdio()
    {
        Greenfoot.playSound("gameover.mp3");
        setImage("gameover.jpg");
        Greenfoot.delay(30);
        Greenfoot.stop();
    }
    
    public void escFinal(int bonus)
    {
         int tiempo = 400;
         
         if(bonus >= 4)
         {
            setImage("bueno1.jpg");
            Greenfoot.delay(tiempo);
            setImage("bueno2.jpg");
            Greenfoot.delay(tiempo);
            setImage("bueno3.jpg");
            Greenfoot.delay(tiempo);
            Greenfoot.playSound("finalbueno.mp3");
            setImage("bueno4.jpg");
            Greenfoot.delay(tiempo);
            setImage("bueno5.jpg");
            Greenfoot.delay(tiempo);
            setImage("bueno6.jpg");
            Greenfoot.delay(tiempo);
            setImage("bueno7.jpg");
            Greenfoot.delay(tiempo);
            setImage("fin.jpg");
            Greenfoot.delay(tiempo);
            Greenfoot.stop();
            }
         else
             escFinalMalo();
        }
        
   public void escFinalMalo()
   {
       int tiempo = 400;
       
       setImage("malo1.jpg");
       Greenfoot.delay(tiempo);
       setImage("malo2.jpg");
       Greenfoot.delay(tiempo);
       Greenfoot.playSound("finalmalo.mp3");
       setImage("malo3.jpg");
       Greenfoot.delay(tiempo);
       setImage("malo3.jpg");
       Greenfoot.delay(tiempo);
       setImage("malo4.jpg");
       Greenfoot.delay(tiempo);
       setImage("malo5.jpg");
       Greenfoot.delay(tiempo);
       setImage("malo6.jpg");
       Greenfoot.delay(tiempo);
       setImage("fin.jpg");
       Greenfoot.delay(tiempo);
       Greenfoot.stop();
    }
    }
