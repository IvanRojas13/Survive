import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Demonios here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Demonio extends Enemigo
{
    private GreenfootImage demonio;
    private int direccion = 1;
    private boolean cambia = false;
    private int velocidad = 3;
    
    /**
     * Act - do whatever the Demonios wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {   
         demonio = new GreenfootImage("demonio.png");
        demonio.scale(150, 150);
        setImage(demonio);
        moviDem();
    }    
    
    /**
     * Mètodo que permite el movimiento de derecha a izquierda del demonio
     */
    public void moviDem()
    {
           
       if(getX() >= 30 && !cambia)
          direccion = -1;
       else
          cambia = true;
       if(getX() <= getWorld().getHeight() - 30 && cambia)
          direccion = 1;
       else
           cambia = false;
           
       setLocation(getX() + ( velocidad  * direccion), getY());
       
    }
}
