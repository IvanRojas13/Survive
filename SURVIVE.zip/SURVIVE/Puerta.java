import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Puerta here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Puerta extends Actor
{
    private GreenfootImage puerta;
    
    /**
     * Act - do whatever the Puerta wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        puerta = new GreenfootImage("puerta.png");
        puerta.scale(90, 100);
        setImage(puerta);
    }    
}
