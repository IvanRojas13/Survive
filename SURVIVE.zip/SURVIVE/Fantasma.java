import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Fantasmas here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Fantasma extends Enemigo
{
    private GreenfootImage fantasma;
    private GreenfootImage invisible;
    
    /**
     * Act - do whatever the Fantasmas wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */ 
    public void act() 
    {
      fantasma = new GreenfootImage("fantasma.png");
      invisible = new GreenfootImage("invisible.png");
        
      fantasma.scale(80, 80);
      invisible.scale(80, 80);
      
      if(getX() >= 300 && getY() <= 450)
         setImage(fantasma);
          else
          setImage(invisible);
      
      super.movimiento();
    }   
}
