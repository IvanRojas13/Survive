import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Fuego here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Fuego extends Enemigo
{
    private GreenfootImage fuego;
    /**
     * Act - do whatever the Fuego wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        fuego = new GreenfootImage("fuego.png");
        fuego.scale(50, 50);
        setImage(fuego);
        super.movimiento();
    }    
}
