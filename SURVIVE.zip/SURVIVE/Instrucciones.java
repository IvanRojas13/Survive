import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Class Instrucciones.
 * Llama al mundo instrucciones para que aparezca en la pantalla
 * @author Pedro Aldo Villela Briones
 * @author Elva Nayeli Bárcenas López
 * @version (1.0)
 */
public class Instrucciones extends Boton
{
    /**
     * Act - do whatever the Instrucciones wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    /**
     * Manda llamar a tocar
     */
    public void act() 
    {
        tocar();
    }    
    
    /**
     * Al tocar el boton hace que cambie de mundo
     */
    public void tocar()
    {
        if(Greenfoot.mouseClicked(this))
        {
            MundoInstr mu = new MundoInstr();
            Greenfoot.setWorld(mu);
        }
    }
}
