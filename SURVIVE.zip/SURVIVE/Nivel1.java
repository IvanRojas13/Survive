import greenfoot.*;

/**
 * Clase nivel 1.
 * Se encarga de pintar los objetos que se mostraran en el nivel puerta, jugador, 
 * vidas, bonus, vidas extras, llave, enemigos(serpiente, bomba, fuego).
 * 
 * @author Pedro Aldo Villela Briones
 * @author Elva Nayeli Bárcenas López
 * @version (1.0)
 */
public class Nivel1 extends World
{
    private int vid;
    private int niv;
    private int bon;
    private int llaveubk;

    Counter count;
    SimpleTimer tim;
    Jugador jug;
     Tablero tablero;
     
    /**
     * Constructor de la clase Nivel1, se enarga de pintar el nivel.
     */
    public Nivel1(int vidas, int bonus, int nivel, int llaveubik)
    {
        super(800, 600, 1);
        Greenfoot.playSound("juego.mp3");
        
        vid = vidas;
        niv = nivel;
        bon = bonus;
        llaveubk = llaveubik;

        jug = new Jugador(vid, bon, niv, llaveubik);
        tablero = new Tablero(vid, "");
        
         addObject(new Vida(), 150, 30);

        count = new Counter();
         this.addObject(count,50,30);
        count.setValue(20);
        
        tim=new SimpleTimer();
        tim.mark();

        if(llaveubk == 0)
        {
         addObject( jug, 30, 510);
         
         addObject(tablero, 148, 34); 
         
         addObject(new Llave(), 30, 100);
       
         addObject(new Serpiente(), 790, 290);
         addObject(new Serpiente(), 790, 330);
        
         addObject(new Bomba(), 790, 270);
         addObject(new Bomba(), 790, 350);
        
         addObject(new Fuego(), 790, 250);
         addObject(new Fuego(), 790, 370);
         
        }
        else
           if(llaveubk == 1)
           {
         addObject(new Puerta(), 780, 495);
         
         addObject( jug, 30, 510);
           
         addObject(tablero, 148, 34);
         addObject(new Bonus(), 600, 100);
         addObject(new Bonus(), 610, 100);
         
         addObject(new VidaExtra(), 400, 100);
            
       
         addObject(new Serpiente(), 790, 290);
         addObject(new Serpiente(), 790, 330);
        
         addObject(new Bomba(), 790, 270);
         addObject(new Bomba(), 790, 350);
       
         addObject(new Fuego(), 790, 250);
         addObject(new Fuego(), 790, 370);
            }
    } 
    
    
    /**
     * Este act sirve para mostrar en pantalla el tiempo que le queda al jugador.
     */
    public void act()
    {
        if(tim.millisElapsed()>1000)
        {
            tim.mark();
            count.setValue(count.getValue()-1);
        }
    }
}
