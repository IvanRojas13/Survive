import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.io.IOException;
/**
 * Esta clase describe al jugador, su movimiento.
 * 
 * @author Pedro Aldo Villela Briones
 * @author Elva Nayeli Bárcenas López
 * @version (1.0)
 */
public class Jugador extends Actor
{
    /**
     * Act - do whatever the Jugador wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    //Atras
    private GreenfootImage atras1;
    private GreenfootImage atras2;
     //Frente
    private GreenfootImage frente;
     //Derecha
    private GreenfootImage derecha1;
    private GreenfootImage derecha2;
    private GreenfootImage derecha3;
    private GreenfootImage derecha4;
    private GreenfootImage derecha5;
     //Izquierda
    private GreenfootImage izquierda1;
    private GreenfootImage izquierda2;
    private GreenfootImage izquierda3;
    private GreenfootImage izquierda4;
    
    private GreenfootImage esc2;
    private GreenfootImage esc3;
    private GreenfootImage gameOver;
    
    private NombreNivel nn;

    private int vida;
    private int bonus;
    private int nivel;
    private int llaveubik;
    
    private SimpleTimer t = new SimpleTimer();
    /**
     * Constructor del jugador
     */
    public Jugador(int vidas, int bonus, int nivel, int llaveubik)
    {
        atras1 = new GreenfootImage("atras2.png");
        atras2 = new GreenfootImage("atras2.png");
        
        frente = new GreenfootImage("frente.png");
        
        derecha1 = new GreenfootImage("derecha1.png");
        derecha2 = new GreenfootImage("derecha2.png");
        derecha3 = new GreenfootImage("derecha3.png");
        derecha4 = new GreenfootImage("derecha4.png");
        derecha5 = new GreenfootImage("derecha5.png");
        
        izquierda1 = new GreenfootImage("izquierda1.png");
        izquierda2 = new GreenfootImage("izquierda2.png");
        izquierda3 = new GreenfootImage("izquierda3.png");
        izquierda4 = new GreenfootImage("izquierda4.png");
        
        
        this.vida = vidas;
        this.bonus = bonus;
        this.nivel = nivel; 
        this.llaveubik = llaveubik;
        
        nn = new NombreNivel();

        setImage(frente);
        t.mark();
    }

    public void act() 
    {
        if(vida == 0)
        {           
             Greenfoot.playSound("gameover.mp3");
            MundoHis mh = new MundoHis();
            NombreNivel nn = new NombreNivel();
            Greenfoot.setWorld(mh);
            mh.addObject(nn, 300, 200);
             Greenfoot.playSound("gameover.mp3");
            nn.escPerdio();
        }
           
        if(nivel == 1)
        {
            if(t.millisElapsed() >= 20000)
            {
                t.mark();
                quitarVida();
                llaveubik = 0;
                Nivel1 n1 = new Nivel1(vida, bonus, nivel, llaveubik);
                Greenfoot.setWorld(n1);
            }
        }
        
        if(nivel == 2)
        {
            if(t.millisElapsed() >= 15000)
            {
                t.mark();
                quitarVida();
                llaveubik = 0;
                Nivel2 n2 = new Nivel2(vida, bonus, nivel, llaveubik);
                Greenfoot.setWorld(n2);
            }
        }
        
        if(nivel == 3)
        {
            if(t.millisElapsed() >= 10000)
            {
                t.mark();
                quitarVida();
                llaveubik = 0;
                Nivel3 n3 = new Nivel3(vida, bonus, nivel, llaveubik);
                Greenfoot.setWorld(n3);
            }
        }
        
        if(isTouching(Bonus.class))
        {
            Greenfoot.playSound("bonus.mp3");
            bonus = bonus + 1;
            removeTouching(Bonus.class);
        }
        
        if(isTouching(Llave.class))
        {
            llaveubik = 1;    
            if(nivel == 1)
            {
             Nivel1 n1 = new Nivel1(vida, bonus, nivel, llaveubik);
             Greenfoot.setWorld(n1);
             }
             else
             if(nivel == 2)
                {
                 Nivel2 n2 = new Nivel2(vida, bonus, nivel, llaveubik);
                 Greenfoot.setWorld(n2);   
                }
                else
                   if(nivel == 3)
                     {
                         Nivel3 n3 = new Nivel3(vida, bonus, nivel, llaveubik);
                         Greenfoot.setWorld(n3);  
                        }
        }
        
        if(isTouching(VidaExtra.class))
        {
            removeTouching(VidaExtra.class);
            vida = vida + 1;
            Greenfoot.playSound("vidaextra.mp3");
            if(nivel == 1)
               {
                    Nivel1 n1 = new Nivel1(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n1);
                }
                else
                if(nivel == 2)
               {
                    Nivel2 n2 = new Nivel2(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n2);
                }
                else
                if(nivel == 3)
               {
                    Nivel3 n3= new Nivel3(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n3);
                }
        }       
        
        if(isTouching(Puerta.class))
        {
            if(nivel == 1)
            {
             MundoHis mh = new MundoHis();
            NombreNivel nn = new NombreNivel();
            Greenfoot.setWorld(mh);
            mh.addObject(nn, 300, 200);
            nn.escNivel2(bonus);
           }
           else
               if(nivel == 2)
               {
               MundoHis mh = new MundoHis();
               NombreNivel nn = new NombreNivel();
               Greenfoot.setWorld(mh);
               mh.addObject(nn, 300, 200);
               nn.escNivel3(bonus);
              }
              else
                  if(nivel == 3)
               {
               MundoHis mh = new MundoHis();
               NombreNivel nn = new NombreNivel();
               Greenfoot.setWorld(mh);
               mh.addObject(nn, 300, 200);
               nn.escFinal(bonus);
              }
       
        }
        movimiento();
        
        if(isTouching(Serpiente.class))
        {
            Greenfoot.playSound("enemigo.mp3");
            quitarVida();
            if(nivel == 1)
               {
                    Nivel1 n1 = new Nivel1(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n1);
                }
                else
                if(nivel == 2)
               {
                    Nivel2 n2 = new Nivel2(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n2);
                }
                else
                if(nivel == 3)
               {
                    Nivel3 n3= new Nivel3(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n3);
                }
        }
        
         if(isTouching(Bomba.class))
        {
            Greenfoot.playSound("explosion.mp3");
            quitarVida();
        if(nivel == 1)
               {
                    Nivel1 n1 = new Nivel1(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n1);
                }
                else
                if(nivel == 2)
               {
                    Nivel2 n2 = new Nivel2(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n2);
                }
                else
                if(nivel == 3)
               {
                    Nivel3 n3= new Nivel3(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n3);
                }
        }

         if(isTouching(Fuego.class))
        {
            Greenfoot.playSound("enemigo.mp3");
            quitarVida();
           if(nivel == 1)
               {
                    Nivel1 n1 = new Nivel1(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n1);
                }
                else
                if(nivel == 2)
               {
                    Nivel2 n2 = new Nivel2(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n2);
                }
                else
                if(nivel == 3)
               {
                    Nivel3 n3= new Nivel3(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n3);
                }
        }
        
         if(isTouching(Fantasma.class))
        {
            Greenfoot.playSound("enemigo.mp3");
            quitarVida();
           if(nivel == 2)
               {
                    Nivel2 n2 = new Nivel2(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n2);
                }
                else
                if(nivel == 3)
               {
                    Nivel3 n3= new Nivel3(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n3);
                }
        }
        
         if(isTouching(Demonio.class))
        {
            Greenfoot.playSound("enemigo.mp3");
            quitarVida();
            if(nivel == 2)
               {
                    Nivel2 n2 = new Nivel2(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n2);
                }
                else
                if(nivel == 3)
               {
                    Nivel3 n3= new Nivel3(vida, bonus, nivel, llaveubik);
                    Greenfoot.setWorld(n3);
                }
        }
        
        if(isTouching(Roca.class) || isTouching(Muro.class))
        {
             setLocation(getX()-2, getY()-2);
             move(0);
        }
    }   
    
   
    public void movimiento()
    {
        if(Greenfoot.isKeyDown("left"))
       { 
           setImage(izquierda1);
           move(-2);
           setImage(izquierda2);
           move(-2);
           setImage(izquierda3);
           move(-1);
           setImage(izquierda4);
           move(-1);
       }
        
         if(Greenfoot.isKeyDown("right"))
        {
           setImage(derecha1);
           move(2);
           setImage(derecha2);
           move(2);
           setImage(derecha3);
           move(0);
           setImage(derecha4);
           move(1);
           setImage(derecha5);
           move(1);
        }
        
        if(Greenfoot.isKeyDown("up"))
        {
           setImage(atras1);
           setLocation(getX(), getY()-2);
           setImage(atras2);
           setLocation(getX(), getY()-1);
        }
        
        if(Greenfoot.isKeyDown("down"))
        {
           setImage(frente);
           setLocation(getX(), getY()+2);
        }
        
        if(isAtEdge())
          move(0);
    }
    
    public void quitarVida()
    {
        vida = vida - 1;
    }
    
    public int getVidas()
    {
        return vida;
    }
    
    public void siguienteNivel()
    {
        if(nivel == 1)
        {
           if(llaveubik == 0)
           {
               Nivel1 n1 = new Nivel1(vida, bonus, nivel, llaveubik);
               Greenfoot.setWorld(n1);
            }
            else
                nn.escNivel2(bonus);
         }
        else
          if(nivel == 2)
          {
             if(llaveubik == 0)
           {
               Nivel2 n2 = new Nivel2(vida, bonus, nivel, llaveubik);
               Greenfoot.setWorld(n2);
            }
            else
                nn.escNivel3(bonus);
          }
        else
          if(nivel == 3)
          {
             if(llaveubik == 0)
           {
               Nivel3 n3 = new Nivel3(vida, bonus, nivel, llaveubik);
               Greenfoot.setWorld(n3);
          }
        }
   }
}