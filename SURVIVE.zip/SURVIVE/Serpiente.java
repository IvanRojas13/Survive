import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Serpiente here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Serpiente extends Enemigo
{
    /**
     * Act - do whatever the Serpiente wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
      private GreenfootImage serpiente;
     
    public void act() 
    {
      serpiente = new GreenfootImage("serpiente.png");
       serpiente.scale(50, 50);
       setImage(serpiente);
      movimSer();
    }  
    
    /**
     * Mètodo que permite el movimiento caracterìstico de las serpientes
     */
    public void movimSer()
    {
        move(1);
        if(Greenfoot.getRandomNumber(100) > 10){
           turn(Greenfoot.getRandomNumber(10) - 5);
        if(getX() <= 5 || getX() >= getWorld().getWidth() - 5)
        {
            turn(180);
        }
        if(getY() <= 5 || getY() >= getWorld().getHeight() - 5)
        {
            turn(180);
        }
      }
    }
}
