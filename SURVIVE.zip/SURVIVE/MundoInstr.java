import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Mundo Instrucciones.
 * Se encarga de mostrar las instrucciones del juego durante un periodo de tiempo 
 * determinado.
 * 
 *@author Pedro Aldo Villela Briones
 * @author Elva Nayeli Bárcenas López
 * @version (1.0)
 */
public class MundoInstr extends World
{

    /**
     * Constructor for objects of class MundoInstr.
     * 
     */
    public MundoInstr()
    {    
        super(1280, 720, 1); 
    }
    
    /**
     * Se encarga de pintar las instrucciones por un periodo de tiempo determinado
     */
    public void act()
    {
        Greenfoot.playSound("menu.mp3");
        Greenfoot.delay(1700);
        MyWorld wu = new MyWorld();
        Greenfoot.setWorld(wu);
    }
}
