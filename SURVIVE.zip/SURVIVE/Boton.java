import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Class Boton.
 * Crea botones para la clase por eso es abstracta.
 * @author Pedro Aldo Villela Briones
 * @author Elva Nayeli Bárcenas López
 * @version (1.0)
 */
public abstract class Boton extends Actor
{
    /**
     * Act - do whatever the Boton wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
    
    public abstract void tocar();
}
