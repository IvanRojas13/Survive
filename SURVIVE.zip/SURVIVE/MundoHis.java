import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Mundo His.
 * Mundo creado para poder redireccionar el rumbo del juego.
 * 
 *@author Pedro Aldo Villela Briones
 * @author Elva Nayeli Bárcenas López
 * @version (1.0)
 */
public class MundoHis extends World
{

    /**
     * Constructor for objects of class MundoHis.
     * 
     */
    public MundoHis()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
    }
}
