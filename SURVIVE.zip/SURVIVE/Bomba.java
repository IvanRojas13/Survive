import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Bombas here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bomba extends Enemigo
{
     private GreenfootImage bomba;
     public GreenfootImage explosion;
    /**
     * Act - do whatever the Bombas wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        int i = 1;
        
       bomba = new GreenfootImage("bomba.png");
       explosion = new GreenfootImage("explosion.png");
       
       bomba.scale(50,50);
       explosion.scale(50,50);
       
       if(getX() >= 300 && getY() >= 100)
         setImage(bomba);
          else
          setImage(explosion);
       
       super.movimiento();
    }  
    }