import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Llave here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Llave extends Actor
{
    private GreenfootImage llave;
        
    /**
     * Act - do whatever the Llave wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
       llave = new GreenfootImage("llave.png");
        llave.scale(30, 30);
        setImage(llave);
    }    
}
